package proyectosgrafos;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;


public class VentanaoPasosDijkstra extends JFrame {


    private JTextArea areaPaso;
    private JTextArea areaManual;

    private JButton btnAnterior;
    private JButton btnSiguiente;


    private ArrayList<String> pasos;


    private int actual = 0;



    public VentanaoPasosDijkstra(
            ArrayList<String> pasos){


        this.pasos = pasos;


        setTitle("Pasos Dijkstra");


        setSize(900,500);


        setLocationRelativeTo(null);


        setLayout(new BorderLayout());




        areaPaso = new JTextArea();

        areaPaso.setFont(
                new Font(
                        "Monospaced",
                        Font.PLAIN,
                        16));

        areaPaso.setEditable(false);



        areaManual = new JTextArea();


        areaManual.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15));


        areaManual.setEditable(false);



        areaManual.setText(

        "MANUAL DIJKSTRA\n\n"

        +"1. Se selecciona un nodo inicial.\n\n"

        +"2. Se asigna distancia 0 al origen.\n\n"

        +"3. Los demás nodos tienen distancia infinita.\n\n"

        +"4. Se escoge el nodo con menor distancia.\n\n"

        +"5. Se revisan sus vecinos.\n\n"

        +"6. Si encuentra una distancia menor,\n"
        +"   se actualiza.\n\n"

        +"7. El proceso termina cuando se\n"
        +"   encuentra la ruta más corta."

        );





        JPanel centro = new JPanel(
                new GridLayout(1,2));



        centro.add(
                new JScrollPane(areaPaso));


        centro.add(
                new JScrollPane(areaManual));



        add(
                centro,
                BorderLayout.CENTER);




        JPanel botones =
                new JPanel();



        btnAnterior =
                new JButton("◀ Anterior");


        btnSiguiente =
                new JButton("Siguiente ▶");



        botones.add(btnAnterior);

        botones.add(btnSiguiente);



        add(
                botones,
                BorderLayout.SOUTH);





        btnAnterior.addActionListener(e->{


            if(actual>0){

                actual--;

                mostrarPaso();

            }


        });




        btnSiguiente.addActionListener(e->{


            if(actual<pasos.size()-1){

                actual++;

                mostrarPaso();

            }


        });




        mostrarPaso();


    }





    private void mostrarPaso(){


        if(!pasos.isEmpty()){


            areaPaso.setText(

                    "PASO "
                    +(actual+1)
                    +"\n\n"
                    +
                    pasos.get(actual)

            );


        }


    }

}