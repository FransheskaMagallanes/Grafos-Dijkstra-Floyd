package proyectosgrafos;

import java.util.ArrayList;

public class Grafo {

    private final ArrayList<Nodo> nodos;
    private final ArrayList<Arista> aristas;

    public Grafo() {
        nodos = new ArrayList<>();
        aristas = new ArrayList<>();
    }

    // Agregar nodo
    public void agregarNodo(Nodo nodo) {
        nodos.add(nodo);
    }

    // Agregar arista
    public void agregarArista(Arista arista) {
        aristas.add(arista);
    }

    // Obtener lista de nodos
    public ArrayList<Nodo> getNodos() {
        return nodos;
    }

    // Obtener lista de aristas
    public ArrayList<Arista> getAristas() {
        return aristas;
    }

    // Buscar un nodo por nombre
    public Nodo buscarNodo(String nombre) {
        for (Nodo n : nodos) {
            if (n.getNombre().equalsIgnoreCase(nombre)) {
                return n;
            }
        }
        return null;
    }

    // Obtener todas las aristas que salen de un nodo
    public ArrayList<Arista> obtenerVecinos(Nodo nodo) {

        ArrayList<Arista> vecinos = new ArrayList<>();

        for (Arista a : aristas) {

            if (a.getOrigen() == nodo) {
                vecinos.add(a);
            }

        }

        return vecinos;
    }

    // Eliminar todo el grafo
    public void limpiar() {
        nodos.clear();
        aristas.clear();
    }

}