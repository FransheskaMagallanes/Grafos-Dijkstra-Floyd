package proyectosgrafos;

import java.util.*;

public class Dijkstra {

    private final Grafo grafo;

    private ArrayList<String> pasos;


    public Dijkstra(Grafo grafo) {

        this.grafo = grafo;
        pasos = new ArrayList<>();

    }



    public Resultado ejecutar(Nodo inicio, Nodo fin) {


        pasos.clear();


        Map<Nodo,Integer> distancia = new HashMap<>();

        Map<Nodo,Nodo> anterior = new HashMap<>();

        PriorityQueue<Registro> cola =
                new PriorityQueue<>();



        // =================================
        // PASO 1: INICIALIZACIÓN
        // =================================


        for(Nodo nodo : grafo.getNodos()){


            distancia.put(
                    nodo,
                    Integer.MAX_VALUE
            );

        }



        distancia.put(inicio,0);



        cola.add(
                new Registro(
                        inicio,
                        0)
        );



        pasos.add(

                "PASO INICIAL\n\n"

                +"Nodo inicial: "
                +inicio.getNombre()

                +"\n\nDistancias iniciales:\n\n"

                +mostrarDistancias(distancia)

        );





        // =================================
        // ALGORITMO DIJKSTRA
        // =================================


        while(!cola.isEmpty()){


            Registro actual = cola.poll();



            if(actual.distancia >
                    distancia.get(actual.nodo)){


                continue;

            }



            pasos.add(

                    "PASO: SELECCIÓN DEL NODO\n\n"

                    +"Nodo seleccionado: "
                    +actual.nodo.getNombre()

                    +"\nDistancia actual: "
                    +actual.distancia

                    +"\n\n"

                    +mostrarDistancias(distancia)

            );





            for(Arista arista :
                    grafo.obtenerVecinos(actual.nodo)){



                Nodo vecino =
                        arista.getDestino();



                int nuevaDistancia =
                        actual.distancia
                        +
                        arista.getPeso();





                pasos.add(

                        "REVISIÓN DE ARISTA\n\n"

                        +"Nodo origen: "
                        +actual.nodo.getNombre()

                        +"\nNodo destino: "
                        +vecino.getNombre()

                        +"\nPeso: "
                        +arista.getPeso()

                        +"\n\n"

                        +"Nueva distancia calculada: "
                        +nuevaDistancia


                );





                if(nuevaDistancia <
                        distancia.get(vecino)){



                    distancia.put(
                            vecino,
                            nuevaDistancia
                    );



                    anterior.put(
                            vecino,
                            actual.nodo
                    );



                    cola.add(
                            new Registro(
                                    vecino,
                                    nuevaDistancia)
                    );



                    pasos.add(

                            "ACTUALIZACIÓN\n\n"

                            +"Se encontró un camino más corto hacia: "

                            +vecino.getNombre()

                            +"\nNueva distancia: "

                            +nuevaDistancia

                            +"\n\nDistancias actuales:\n\n"

                            +mostrarDistancias(distancia)

                    );



                }
                else{


                    pasos.add(

                            "SIN CAMBIOS\n\n"

                            +"La distancia actual hacia "

                            +vecino.getNombre()

                            +" es menor."

                    );


                }


            }


        }







        // =================================
        // CONSTRUIR CAMINO FINAL
        // =================================


        ArrayList<Arista> camino =
                new ArrayList<>();



        if(distancia.get(fin)
                == Integer.MAX_VALUE){



            pasos.add(

                    "RESULTADO FINAL\n\n"

                    +"No existe camino entre "

                    +inicio.getNombre()

                    +" y "

                    +fin.getNombre()

            );


            abrirVentana();


            return new Resultado(camino,-1);

        }





        Nodo actual = fin;



        while(anterior.containsKey(actual)){


            Nodo previo =
                    anterior.get(actual);



            for(Arista arista:
                    grafo.getAristas()){


                if(arista.getOrigen()==previo
                        &&
                   arista.getDestino()==actual){


                    camino.add(
                            0,
                            arista
                    );

                    break;

                }


            }



            actual = previo;


        }







        StringBuilder recorrido =
                new StringBuilder();



        recorrido.append(
                inicio.getNombre()
        );



        for(Arista a: camino){


            recorrido.append(" → ");

            recorrido.append(
                    a.getDestino()
                    .getNombre()
            );

        }






        pasos.add(

                "RESULTADO FINAL\n\n"

                +"Origen: "
                +inicio.getNombre()

                +"\nDestino: "
                +fin.getNombre()

                +"\n\nCamino más corto:\n"

                +recorrido

                +"\n\nDistancia mínima: "

                +distancia.get(fin)

        );




        abrirVentana();




        return new Resultado(
                camino,
                distancia.get(fin)
        );


    }






    private void abrirVentana(){


        VentanaoPasosDijkstra ventana =
                new VentanaoPasosDijkstra(
                        pasos
                );


        ventana.setVisible(true);


    }







    private String mostrarDistancias(
            Map<Nodo,Integer> distancia){



        StringBuilder texto =
                new StringBuilder();



        for(Nodo n: grafo.getNodos()){


            texto.append(
                    n.getNombre()
            );


            texto.append(" = ");



            if(distancia.get(n)
                    == Integer.MAX_VALUE){


                texto.append("∞");


            }
            else{


                texto.append(
                        distancia.get(n)
                );


            }


            texto.append("\n");


        }



        return texto.toString();


    }








    public static class Resultado {


        private final ArrayList<Arista> camino;

        private final int distancia;



        public Resultado(
                ArrayList<Arista> camino,
                int distancia){


            this.camino = camino;

            this.distancia = distancia;


        }



        public ArrayList<Arista> getCamino(){

            return camino;

        }



        public int getDistancia(){

            return distancia;

        }


    }







    private static class Registro
            implements Comparable<Registro>{



        Nodo nodo;

        int distancia;



        public Registro(
                Nodo nodo,
                int distancia){


            this.nodo=nodo;

            this.distancia=distancia;


        }




        @Override
        public int compareTo(
                Registro otro){


            return Integer.compare(
                    this.distancia,
                    otro.distancia
            );


        }


    }


}