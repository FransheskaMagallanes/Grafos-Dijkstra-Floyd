package proyectosgrafos;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class VentanaDijkstra extends JFrame {

    public VentanaDijkstra(Dijkstra.Resultado resultado,
                           Nodo inicio,
                           Nodo fin) {

        setTitle("Resultado Dijkstra");
        setSize(500,300);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        String[] columnas = {"Origen", "Destino", "Distancia", "Camino"};

        DefaultTableModel modelo = new DefaultTableModel(columnas,0);

        StringBuilder camino = new StringBuilder();

        camino.append(inicio.getNombre());

        for (Arista a : resultado.getCamino()) {
            camino.append(" → ").append(a.getDestino().getNombre());
        }

        modelo.addRow(new Object[]{
            inicio.getNombre(),
            fin.getNombre(),
            resultado.getDistancia(),
            camino.toString()
        });

        JTable tabla = new JTable(modelo);

        tabla.setRowHeight(35);
        tabla.setEnabled(false);

        JScrollPane scroll = new JScrollPane(tabla);

        add(scroll, BorderLayout.CENTER);

        JLabel titulo = new JLabel(
                "Resultado del algoritmo Dijkstra",
                SwingConstants.CENTER);

        titulo.setFont(new Font("Arial", Font.BOLD, 18));

        add(titulo, BorderLayout.NORTH);

        setVisible(true);
    }

}