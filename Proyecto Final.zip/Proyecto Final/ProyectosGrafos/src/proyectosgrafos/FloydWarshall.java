package proyectosgrafos;

import java.util.ArrayList;

public class FloydWarshall {

    private final Grafo grafo;

    private static final int INF = 999999;

    private ArrayList<int[][]> pasos;
    private ArrayList<String> nombresPasos;


    public FloydWarshall(Grafo grafo) {

        this.grafo = grafo;

        pasos = new ArrayList<>();
        nombresPasos = new ArrayList<>();

    }


    public int[][] ejecutar() {


        int n = grafo.getNodos().size();


        if(n == 0){
            return null;
        }


        int[][] dist = new int[n][n];


        // MATRIZ INICIAL

        for(int i=0;i<n;i++){

            for(int j=0;j<n;j++){

                if(i==j)

                    dist[i][j]=0;

                else

                    dist[i][j]=INF;

            }

        }



        // Cargar aristas

        for(Arista a : grafo.getAristas()){


            int origen =
                    grafo.getNodos()
                    .indexOf(a.getOrigen());


            int destino =
                    grafo.getNodos()
                    .indexOf(a.getDestino());


            dist[origen][destino]=a.getPeso();

        }



        guardarPaso(
                dist,
                "MATRIZ INICIAL"
        );



        // Floyd Warshall

        for(int k=0;k<n;k++){


            for(int i=0;i<n;i++){


                for(int j=0;j<n;j++){


                    if(dist[i][k]!=INF &&
                       dist[k][j]!=INF &&
                       dist[i][k]+dist[k][j]<dist[i][j]){


                        dist[i][j]=
                                dist[i][k]+dist[k][j];


                    }

                }

            }



            guardarPaso(
                    dist,
                    "ITERACIÓN K = "
                    +
                    grafo.getNodos()
                    .get(k)
                    .getNombre()
            );


        }




        VentanaoPasosFloydWarshall ventana =
                new VentanaoPasosFloydWarshall(
                        pasos,
                        nombresPasos,
                        grafo
                );


        ventana.setVisible(true);



        return dist;

    }





    private void guardarPaso(int[][] matriz,String nombre){


        int n = matriz.length;


        int[][] copia = new int[n][n];


        for(int i=0;i<n;i++){

            for(int j=0;j<n;j++){

                copia[i][j]=matriz[i][j];

            }

        }


        pasos.add(copia);

        nombresPasos.add(nombre);

    }


}