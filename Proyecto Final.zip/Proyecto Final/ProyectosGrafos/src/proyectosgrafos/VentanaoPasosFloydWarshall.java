package proyectosgrafos;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;


public class VentanaoPasosFloydWarshall extends JFrame {


    private JTable tabla;

    private DefaultTableModel modelo;


    private JLabel titulo;


    private JTextArea manual;


    private JButton btnAnterior;
    private JButton btnSiguiente;


    private ArrayList<int[][]> pasos;

    private ArrayList<String> nombres;


    private Grafo grafo;


    private int posicion = 0;



    public VentanaoPasosFloydWarshall(
            ArrayList<int[][]> pasos,
            ArrayList<String> nombres,
            Grafo grafo){


        this.pasos = pasos;

        this.nombres = nombres;

        this.grafo = grafo;



        setTitle(
                "Pasos Floyd-Warshall"
        );


        setSize(1000,600);


        setLocationRelativeTo(null);


        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE);



        crearInterfaz();


        mostrarPaso();


    }



    private void crearInterfaz(){


        setLayout(new BorderLayout());



        titulo = new JLabel(
                "",
                SwingConstants.CENTER
        );


        titulo.setFont(
                new Font(
                "Arial",
                Font.BOLD,
                22));


        add(titulo,
                BorderLayout.NORTH);




        modelo =
                new DefaultTableModel();


        tabla =
                new JTable(modelo);



        tabla.setRowHeight(30);


        tabla.setFont(
                new Font(
                "Arial",
                Font.BOLD,
                15));



        JScrollPane tablaScroll =
                new JScrollPane(tabla);





        manual = new JTextArea();


        manual.setEditable(false);


        manual.setFont(
                new Font(
                "Arial",
                Font.PLAIN,
                14));



        manual.setText(

        "MANUAL FLOYD-WARSHALL\n\n"

        +"• La matriz muestra las distancias\n"
        +"  entre cada par de nodos.\n\n"

        +"• K es el nodo intermedio.\n\n"

        +"• Se prueba si pasar por K\n"
        +"  genera un camino más corto.\n\n"

        +"Formula:\n\n"

        +"D(i,j)=min(D(i,j),\n"
        +"D(i,k)+D(k,j))\n\n"

        +"Si el nuevo valor es menor,\n"
        +"se reemplaza la distancia."

        );



        JScrollPane manualScroll =
                new JScrollPane(manual);




        JSplitPane division =
                new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                tablaScroll,
                manualScroll);



        division.setDividerLocation(650);



        add(division,
                BorderLayout.CENTER);





        JPanel botones =
                new JPanel();



        btnAnterior =
                new JButton("<< Anterior");


        btnSiguiente =
                new JButton("Siguiente >>");



        botones.add(btnAnterior);

        botones.add(btnSiguiente);



        add(botones,
                BorderLayout.SOUTH);




        btnAnterior.addActionListener(e->{


            if(posicion>0){

                posicion--;

                mostrarPaso();

            }


        });




        btnSiguiente.addActionListener(e->{


            if(posicion < pasos.size()-1){


                posicion++;


                mostrarPaso();


            }


        });



    }






    private void mostrarPaso(){


        titulo.setText(
                nombres.get(posicion)
        );



        modelo.setRowCount(0);

        modelo.setColumnCount(0);



        modelo.addColumn("");



        for(Nodo n:
                grafo.getNodos()){


            modelo.addColumn(
                    n.getNombre()
            );


        }




        int[][] matriz =
                pasos.get(posicion);




        for(int i=0;i<matriz.length;i++){


            Object fila[] =
                    new Object[
                    matriz.length+1];



            fila[0]=
                    grafo.getNodos()
                    .get(i)
                    .getNombre();




            for(int j=0;j<matriz.length;j++){


                if(matriz[i][j]==999999)

                    fila[j+1]="∞";

                else

                    fila[j+1]=matriz[i][j];


            }


            modelo.addRow(fila);


        }



    }



}