package proyectosgrafos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaPrincipal extends JFrame implements ActionListener {

    private final Grafo grafo;
    private final PanelGrafo panel;

    private final JButton btnNodo;
    private final JButton btnArista;
    private final JButton btnMover;
    private final JButton btnInicio;
    private final JButton btnFin;
    private final JButton btnDijkstra;
    private final JButton btnFloyd;
    private final JButton btnColorNodo;
    private final JButton btnColorFondo;
    private final JButton btnLimpiar;
    private final JButton btnSalir;

    public VentanaPrincipal() {

        super("Algoritmos de Grafos");

        grafo = new Grafo();
        panel = new PanelGrafo(grafo);

        setLayout(new BorderLayout());

        JPanel barra = new JPanel(new FlowLayout(FlowLayout.LEFT));

        btnNodo = new JButton("Agregar Nodo");
        btnArista = new JButton("Agregar Arista");
        btnMover = new JButton("Mover Nodo");
        btnInicio = new JButton("Nodo Inicio");
        btnFin = new JButton("Nodo Fin");
        btnDijkstra = new JButton("Dijkstra");
        btnFloyd = new JButton("Floyd-Warshall");
        btnColorNodo = new JButton("Color Nodo");
        btnColorFondo = new JButton("Color Fondo");
        btnLimpiar = new JButton("Limpiar");
        btnSalir = new JButton("Salir");

        barra.add(btnNodo);
        barra.add(btnArista);
        barra.add(btnMover);
        barra.add(btnInicio);
        barra.add(btnFin);
        barra.add(btnDijkstra);
        barra.add(btnFloyd);
        barra.add(btnColorNodo);
        barra.add(btnColorFondo);
        barra.add(btnLimpiar);
        barra.add(btnSalir);

        add(barra, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);

        btnNodo.addActionListener(this);
        btnArista.addActionListener(this);
        btnMover.addActionListener(this);
        btnInicio.addActionListener(this);
        btnFin.addActionListener(this);
        btnDijkstra.addActionListener(this);
        btnFloyd.addActionListener(this);
        btnColorNodo.addActionListener(this);
        btnColorFondo.addActionListener(this);
        btnLimpiar.addActionListener(this);
        btnSalir.addActionListener(this);

        setSize(1100, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        Object fuente = e.getSource();

        if (fuente == btnNodo) {
            panel.activarAgregarNodo();
        } else if (fuente == btnArista) {
            panel.activarAgregarArista();
        } else if (fuente == btnMover) {
            panel.activarMover();
        } else if (fuente == btnInicio) {
            panel.activarSeleccionInicio();
        } else if (fuente == btnFin) {
            panel.activarSeleccionFin();
        } else if (fuente == btnColorNodo) {
            panel.cambiarColorNodo();
        } else if (fuente == btnColorFondo) {

            Color color = JColorChooser.showDialog(
                    this,
                    "Seleccione un color",
                    Color.WHITE);

            if (color != null) {
                panel.cambiarColorFondo(color);
            }

        } else if (fuente == btnLimpiar) {

            panel.limpiar();

        } else if (fuente == btnSalir) {

            System.exit(0);

        } else if (fuente == btnDijkstra) {

            if (panel.getNodoInicio() == null
                    || panel.getNodoFin() == null) {

                JOptionPane.showMessageDialog(
                        this,
                        "Seleccione el nodo de inicio y el nodo final.");

                return;
            }

            Dijkstra algoritmo = new Dijkstra(grafo);

            Dijkstra.Resultado resultado
                    = algoritmo.ejecutar(
                            panel.getNodoInicio(),
                            panel.getNodoFin());

            panel.setCaminoDijkstra(resultado.getCamino());

            if (resultado.getDistancia() == -1) {

                JOptionPane.showMessageDialog(
                        this,
                        "No existe un camino entre esos nodos.");

            } else {

                StringBuilder camino = new StringBuilder();

                camino.append(panel.getNodoInicio().getNombre());

                for (Arista a : resultado.getCamino()) {

                    camino.append(" → ")
                            .append(a.getDestino().getNombre());

                }

                new VentanaDijkstra(
                        resultado,
                        panel.getNodoInicio(),
                        panel.getNodoFin());
            }

        } else if (fuente == btnFloyd) {

            if (grafo.getNodos().isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Primero agregue nodos al grafo.");

                return;

            }

            FloydWarshall floyd = new FloydWarshall(grafo);


            int[][] matriz = floyd.ejecutar ();

          
        }

    }

    @Override
    public Component add(Component comp) {
        throw new UnsupportedOperationException("Not supported yet.");
}
}
