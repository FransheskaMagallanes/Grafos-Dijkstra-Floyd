package proyectosgrafos;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class PanelGrafo extends JPanel
        implements MouseListener, MouseMotionListener {

    private Grafo grafo;

    private Nodo nodoSeleccionado = null;
    private Nodo primerNodo = null;
    private Nodo nodoInicio = null;
    private Nodo nodoFin = null;

    private boolean agregarNodo;
    private boolean agregarArista;
    private boolean seleccionarInicio;
    private boolean seleccionarFin;
    private boolean moverNodo;

    private int offsetX;
    private int offsetY;

    private Color colorFondo = Color.WHITE;

    private ArrayList<Arista> caminoDijkstra;

    public PanelGrafo(Grafo grafo) {

        this.grafo = grafo;

        caminoDijkstra = new ArrayList<>();

        setBackground(colorFondo);

        addMouseListener(this);
        addMouseMotionListener(this);

    }

    public void activarAgregarNodo() {

        agregarNodo = true;
        agregarArista = false;
        seleccionarInicio = false;
        seleccionarFin = false;
        moverNodo = false;

    }

    public void activarAgregarArista() {

        agregarNodo = false;
        agregarArista = true;
        seleccionarInicio = false;
        seleccionarFin = false;
        moverNodo = false;

    }

    public void activarSeleccionInicio() {

        agregarNodo = false;
        agregarArista = false;
        seleccionarInicio = true;
        seleccionarFin = false;
        moverNodo = false;

    }

    public void activarSeleccionFin() {

        agregarNodo = false;
        agregarArista = false;
        seleccionarInicio = false;
        seleccionarFin = true;
        moverNodo = false;

    }

    public void activarMover() {

        agregarNodo = false;
        agregarArista = false;
        seleccionarInicio = false;
        seleccionarFin = false;
        moverNodo = true;

    }

    public Nodo getNodoInicio() {
        return nodoInicio;
    }

    public Nodo getNodoFin() {
        return nodoFin;
    }

    public void setCaminoDijkstra(ArrayList<Arista> camino) {

        caminoDijkstra = camino;
        repaint();

    }

    public void limpiar() {

        grafo.limpiar();

        nodoInicio = null;
        nodoFin = null;
        primerNodo = null;
        nodoSeleccionado = null;

        caminoDijkstra.clear();

        repaint();

    }

    public void cambiarColorFondo(Color color){

        colorFondo = color;

        setBackground(color);

        repaint();

    }
     @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);

        Graphics2D g2 = (Graphics2D) g;

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        // ===== DIBUJAR ARISTAS =====

        for (Arista a : grafo.getAristas()) {

            boolean camino = caminoDijkstra.contains(a);

            if (camino) {

                g2.setColor(Color.RED);
                g2.setStroke(new BasicStroke(5));

            } else {

                g2.setColor(Color.DARK_GRAY);
                g2.setStroke(new BasicStroke(3));

            }

            dibujarFlecha(
                    g2,
                    a.getOrigen().getX(),
                    a.getOrigen().getY(),
                    a.getDestino().getX(),
                    a.getDestino().getY());

            int xm = (a.getOrigen().getX() + a.getDestino().getX()) / 2;
            int ym = (a.getOrigen().getY() + a.getDestino().getY()) / 2;

            g2.setColor(Color.WHITE);
            g2.fillRoundRect(xm - 15, ym - 12, 32, 22, 8, 8);

            g2.setColor(Color.BLACK);
            g2.drawRoundRect(xm - 15, ym - 12, 32, 22, 8, 8);

            g2.drawString(
                    String.valueOf(a.getPeso()),
                    xm - 5,
                    ym + 5);

        }

        // ===== DIBUJAR NODOS =====

        for (Nodo n : grafo.getNodos()) {

            Color color = n.getColor();

            if (n == nodoInicio) {

                color = new Color(34,197,94);

            } else if (n == nodoFin) {

                color = new Color(239,68,68);

            }

            g2.setColor(color);

            g2.fillOval(
                    n.getX()-25,
                    n.getY()-25,
                    50,
                    50);

            g2.setColor(Color.WHITE);

            g2.setStroke(new BasicStroke(2));

            g2.drawOval(
                    n.getX()-25,
                    n.getY()-25,
                    50,
                    50);

            g2.setColor(Color.BLACK);

            FontMetrics fm = g2.getFontMetrics();

            int x = n.getX()
                    - fm.stringWidth(n.getNombre())/2;

            int y = n.getY()
                    + fm.getAscent()/2;

            g2.drawString(
                    n.getNombre(),
                    x,
                    y);

        }

    }

    private final void dibujarFlecha(
            Graphics2D g2,
            int x1,
            int y1,
            int x2,
            int y2){

        double dx = x2 - x1;
        double dy = y2 - y1;

        double angulo = Math.atan2(dy, dx);

        int radio = 25;

        int inicioX =
                (int)(x1 + radio*Math.cos(angulo));

        int inicioY =
                (int)(y1 + radio*Math.sin(angulo));

        int finX =
                (int)(x2 - radio*Math.cos(angulo));

        int finY =
                (int)(y2 - radio*Math.sin(angulo));

        g2.drawLine(
                inicioX,
                inicioY,
                finX,
                finY);

        int tam = 12;

        Polygon flecha = new Polygon();

        flecha.addPoint(finX, finY);

        flecha.addPoint(

                (int)(finX
                - tam*Math.cos(angulo-Math.PI/6)),

                (int)(finY
                - tam*Math.sin(angulo-Math.PI/6))

        );

        flecha.addPoint(

                (int)(finX
                - tam*Math.cos(angulo+Math.PI/6)),

                (int)(finY
                - tam*Math.sin(angulo+Math.PI/6))

        );

        g2.fillPolygon(flecha);

    }

    private final Nodo buscarNodo(int x,int y){

        for(Nodo n : grafo.getNodos()){

            double d = Math.sqrt(

                    Math.pow(x-n.getX(),2)+
                    Math.pow(y-n.getY(),2)

            );

            if(d<=25){

                return n;

            }

        }

        return null;

    }
@Override
    public void mousePressed(MouseEvent e) {

        Nodo nodo = buscarNodo(e.getX(), e.getY());

        // AGREGAR NODO
        if (agregarNodo) {

            String nombre = JOptionPane.showInputDialog(
                    this,
                    "Nombre del nodo:");

            if (nombre != null && !nombre.trim().isEmpty()) {

                grafo.agregarNodo(
                        new Nodo(
                                e.getX(),
                                e.getY(),
                                nombre.trim()));

                repaint();
            }

            return;
        }

        // AGREGAR ARISTA
        if (agregarArista) {

            if (nodo == null)
                return;

            if (primerNodo == null) {

                primerNodo = nodo;

            } else {

                if (primerNodo != nodo) {

                    String pesoTexto = JOptionPane.showInputDialog(
                            this,
                            "Peso de la arista:");

                    if (pesoTexto != null) {

                        try {

                            int peso = Integer.parseInt(pesoTexto);

                            grafo.agregarArista(
                                    new Arista(
                                            primerNodo,
                                            nodo,
                                            peso));

                        } catch (NumberFormatException ex) {

                            JOptionPane.showMessageDialog(
                                    this,
                                    "Ingrese un número válido.");

                        }

                    }

                }

                primerNodo = null;

                repaint();

            }

            return;
        }

        // SELECCIONAR INICIO
        if (seleccionarInicio && nodo != null) {

            nodoInicio = nodo;

            seleccionarInicio = false;

            repaint();

            return;

        }

        // SELECCIONAR FIN
        if (seleccionarFin && nodo != null) {

            nodoFin = nodo;

            seleccionarFin = false;

            repaint();

            return;

        }

        // MOVER NODO
        if (moverNodo && nodo != null) {

            nodoSeleccionado = nodo;

            offsetX = e.getX() - nodo.getX();

            offsetY = e.getY() - nodo.getY();

        }

    }

    @Override
    public void mouseDragged(MouseEvent e) {

        if (nodoSeleccionado != null) {

            nodoSeleccionado.setX(
                    e.getX() - offsetX);

            nodoSeleccionado.setY(
                    e.getY() - offsetY);

            repaint();

        }

    }

    @Override
    public void mouseReleased(MouseEvent e) {

        nodoSeleccionado = null;

    }

    // Cambiar color de un nodo
    public void cambiarColorNodo() {

        String nombre = JOptionPane.showInputDialog(
                this,
                "Nombre del nodo:");

        if (nombre == null)
            return;

        Nodo nodo = grafo.buscarNodo(nombre);

        if (nodo == null) {

            JOptionPane.showMessageDialog(
                    this,
                    "Nodo no encontrado.");

            return;
        }

        Color color = JColorChooser.showDialog(
                this,
                "Seleccione un color",
                nodo.getColor());

        if (color != null) {

            nodo.setColor(color);

            repaint();

        }

    }

    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    @Override
    public void mouseMoved(MouseEvent e) {}

}