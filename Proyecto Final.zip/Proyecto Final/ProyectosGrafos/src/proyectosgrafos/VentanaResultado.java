package proyectosgrafos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class VentanaResultado extends JFrame {

    public VentanaResultado(Grafo grafo, int[][] matriz) {

        setTitle("Resultado Floyd-Warshall");

        setSize(700,500);

        setLocationRelativeTo(null);

        setLayout(new BorderLayout());

        ArrayList<Nodo> nodos = grafo.getNodos();

        String[] columnas = new String[nodos.size()+1];

        columnas[0] = "";

        for(int i=0;i<nodos.size();i++){

            columnas[i+1]=nodos.get(i).getNombre();

        }

        DefaultTableModel modelo =
                new DefaultTableModel(columnas,0);

        final int INF = 999999;

        int menor = Integer.MAX_VALUE;
        int mayor = 0;

        for(int i=0;i<nodos.size();i++){

            Object[] fila = new Object[nodos.size()+1];

            fila[0]=nodos.get(i).getNombre();

            for(int j=0;j<nodos.size();j++){

                if(matriz[i][j]==INF){

                    fila[j+1]="INF";

                }else{

                    fila[j+1]=matriz[i][j];

                    if(i!=j){

                        if(matriz[i][j]<menor)
                            menor=matriz[i][j];

                        if(matriz[i][j]>mayor)
                            mayor=matriz[i][j];

                    }

                }

            }

            modelo.addRow(fila);

        }

        JTable tabla = new JTable(modelo);

        tabla.setRowHeight(30);

        tabla.setEnabled(false);

        JScrollPane scroll =
                new JScrollPane(tabla);

        add(scroll,BorderLayout.CENTER);

        JLabel informacion =
                new JLabel(
                "Distancia más corta: "
                + menor
                + "     Distancia más larga: "
                + mayor,
                SwingConstants.CENTER);

        informacion.setFont(
                new Font("Arial",
                Font.BOLD,
                16));

        add(informacion,BorderLayout.SOUTH);

        setVisible(true);

    }

}