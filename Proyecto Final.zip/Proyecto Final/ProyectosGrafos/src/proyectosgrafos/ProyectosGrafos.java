package proyectosgrafos;

import javax.swing.SwingUtilities;

public class ProyectosGrafos {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            new VentanaPrincipal();

        });

    }

}